REQUIRED LIBS: numpy
python version: 3.9.7
run main.py